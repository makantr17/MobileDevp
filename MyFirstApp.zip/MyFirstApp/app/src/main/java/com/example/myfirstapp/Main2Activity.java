package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    Button ToastButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ToastButton = findViewById(R.id.TstBtn);
    }

    public void ToastMessage(View view){
//        Toast.makeText(this, "this si a toast Message", Toast.LENGTH_LONG);
        Toast. makeText(this,"Hello Javatpoint",Toast. LENGTH_SHORT).show();
       
    }
}
