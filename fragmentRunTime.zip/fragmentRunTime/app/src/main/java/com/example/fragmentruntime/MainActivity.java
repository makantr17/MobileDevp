package com.example.fragmentruntime;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
//    public static FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_first);

        FragmentTransaction fragmentTransaction= getSupportFragmentManager().beginTransaction();

        fragmentTransaction.add(R.id.fragment_container,new FirstFragment());
        fragmentTransaction.commit();



//        fragmentManager= getSupportFragmentManager();
//
//        if(findViewById(R.id.Fragment_Container)!=null){
//            if(savedInstanceState!=null){
//                return;
//            }
//            FragmentTransaction ft= fragmentManager.beginTransaction();
//            FirstFragment frag1 = new FirstFragment();
//            ft.add(R.id.Fragment_Container, frag1, null);
//            ft.commit();
//
//        }
    }
}
