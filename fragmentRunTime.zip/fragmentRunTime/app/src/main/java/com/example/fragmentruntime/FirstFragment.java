package com.example.fragmentruntime;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class FirstFragment extends Fragment {

    public  View onCreatView(LayoutInflater inflater, ViewGroup container, Bundle savedIntanceState){
        View view = inflater.inflate(R.layout.fragment_first, container, false);
        Button btnFragment = (Button)view.findViewById(R.id.btnFragment1);

        btnFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fr=getFragmentManager().beginTransaction();
                fr.replace(R.id.fragment_container,new SecondFragment());
                fr.commit();
            }
        });
        return view;
    }


}
