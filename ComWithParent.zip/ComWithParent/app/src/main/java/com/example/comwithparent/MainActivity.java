package com.example.comwithparent;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView t1, t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction t=manager.beginTransaction();

        Myfragment m=new Myfragment();
        t.add(R.id.linear1,m);
        t.commit();
    }

    public void f1(String s1, String s2){
        t1=(TextView) findViewById(R.id.text12);
        t2=(TextView) findViewById(R.id.text123);
        t1.setText(s1);
        t2.setText(s2);
    }
}
